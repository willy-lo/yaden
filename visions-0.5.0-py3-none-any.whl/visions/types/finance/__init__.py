"""Namespace for financial types (e.g. currencies)"""
