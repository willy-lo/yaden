"""This module contains (predefined) relations."""
from visions.relations.relations import (
    IdentityRelation,
    InferenceRelation,
    TypeRelation,
)
